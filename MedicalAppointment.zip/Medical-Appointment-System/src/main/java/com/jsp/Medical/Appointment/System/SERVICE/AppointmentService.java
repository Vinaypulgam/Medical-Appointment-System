package com.jsp.Medical.Appointment.System.SERVICE;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.Medical.Appointment.System.DTO.Appointment;
import com.jsp.Medical.Appointment.System.REPOSITORY.AppointmentRepository;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository repository;

    // Insert a new appointment
    public Appointment insertAppointment(Appointment appointment) {
        return repository.save(appointment);
    }

    // Retrieve all appointments
    public List<Appointment> getAllAppointments() {
        return repository.findAll();
    }

    // Retrieve a specific appointment by ID
    public Appointment getAppointmentById(long id) {
        Optional<Appointment> appointment = repository.findById(id);
        return appointment.orElse(null);
    }

    // Delete an appointment by ID
    public String deleteAppointmentById(long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return "Appointment deleted successfully.";
        } else {
            return "Appointment not found.";
        }
    }

    // Update an appointment's date/time
    public String updateAppointment(long id, String newDateTime) {
        Optional<Appointment> appointmentOpt = repository.findById(id);
        if (appointmentOpt.isPresent()) {
            Appointment appointment = appointmentOpt.get();
            appointment.setNewDateTime(newDateTime);
            repository.save(appointment);
            return "Appointment updated successfully.";
        } else {
            return "Appointment not found.";
        }
    }

    // Retrieve appointments by doctor name
    public List<Appointment> getAppointmentsByDoctor(String doctorName) {
        return repository.findByDoctorName(doctorName);
    }

    // Retrieve appointments by patient name
    public List<Appointment> getAppointmentsByPatient(String patientName) {
        return repository.findByPatientName(patientName);
    }
}
