package com.jsp.Medical.Appointment.System.CONTROLLER;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.jsp.Medical.Appointment.System.DTO.Appointment;
import com.jsp.Medical.Appointment.System.SERVICE.AppointmentService;

@RestController
@RequestMapping("/appointments") // Base URL for all appointment-related endpoints
public class AppointmentController {

    @Autowired
     AppointmentService Appointmentservice;

    // REST API to Schedule a New Appointment
    @PostMapping
    public Appointment scheduleAppointment(@RequestBody Appointment appointment) {
        return Appointmentservice.insertAppointment(appointment);
    }

    // REST API to Retrieve All Appointments
    @GetMapping
    public List<Appointment> getAllAppointments() {
        return Appointmentservice.getAllAppointments();
    }

    // REST API to Retrieve a Specific Appointment by ID
    @GetMapping("/byid")
    public Appointment getAppointmentById(@RequestParam long id) {
        return Appointmentservice.getAppointmentById(id);
    }

    // REST API to Delete an Appointment by ID
    @DeleteMapping
    public String cancelAppointment(@RequestParam long id) {
        return Appointmentservice.deleteAppointmentById(id);
    }

    // REST API to Update Appointment Details (New Date & Time)
    @PutMapping
    public String updateAppointment(@RequestParam long id, @RequestParam String newDateTime) {
        return Appointmentservice.updateAppointment(id, newDateTime);
    }

    // REST API to Retrieve Appointments by Doctor Name
    @GetMapping("/bydoctor")
    public List<Appointment> getAppointmentsByDoctor(@RequestParam String doctorName) {
        return Appointmentservice.getAppointmentsByDoctor(doctorName);
    }

    // REST API to Retrieve Appointments by Patient Name
    @GetMapping("/bypatient")
    public List<Appointment> getAppointmentsByPatient(@RequestParam String patientName) {
        return Appointmentservice.getAppointmentsByPatient(patientName);
    }
}
