package com.jsp.Medical.Appointment.System.REPOSITORY;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jsp.Medical.Appointment.System.DTO.Appointment;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    // Custom query methods to find appointments by doctor or patient name
    List<Appointment> findByDoctorName(String doctorName);

    List<Appointment> findByPatientName(String patientName);
}
