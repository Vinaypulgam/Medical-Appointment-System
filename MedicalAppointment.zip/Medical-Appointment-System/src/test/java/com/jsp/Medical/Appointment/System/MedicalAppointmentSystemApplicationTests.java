package com.jsp.Medical.Appointment.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalAppointmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
